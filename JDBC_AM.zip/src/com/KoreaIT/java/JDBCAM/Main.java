package com.KoreaIT.java.JDBCAM;

public class Main {

	public static void main(String[] args) {
		System.out.println("==프로그램 시작==");
		new App().run();
	}
}